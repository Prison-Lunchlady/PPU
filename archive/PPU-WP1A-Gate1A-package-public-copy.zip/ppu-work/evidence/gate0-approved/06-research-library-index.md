# Research Library Index
Record revision 0.2 • 2026-09-19 America/Chicago

## Evidence registry
| ID | Record | Status |
|---|---|---|
| SRC-001 | [Original roadmap](evidence/roadmap-v0.1-original.txt); 07 is verbatim mirror | Governing adopted v0.1; unchanged |
| SRC-002 | [Initial proposal](evidence/initial-proposal.md) | Historical goals and candidates |
| SRC-003 | [Complete supplied recovery](evidence/PPU_full_recovered_source.txt), supplemented by [partial original capture](evidence/architecture-response-PARTIAL.md) | COMPLETE as user-supplied recovery; partial retained for alignment and citation markers |
| SRC-004 | [Phase 0 state](evidence/phase0-source.md) | Later hypothesis-status qualification and inherited registers |
| SRC-005 | [Original reader capture](evidence/conversation-recovered.json) | Bounded metadata/messages; not full export |
| SRC-006 | [Original authorization](evidence/wp0a-authorization.md) plus current user recovery authorization and named source file | WP0A only, no redesign, no ratification, no WP1A |
| SRC-007 | [Self-review](reviews/wp0a-structural-review.md) | Historical findings; source blocker subsequently resolved |
| SRC-008 | [Claude review reconciliation](reviews/claude-opus-reconciliation.md) | Prior packet only; no re-review claim |
| SRC-009 | [Current source reconciliation](reviews/source-recovery-reconciliation.md) | User supplied full response provenance, mappings and closure |

## SRC003 provenance and completeness
User path: D:/Haigler Digital/PPU/PPU_full_recovered_source.txt.
Evidence SHA256: 237A8EEA4F2D64B6B83C597DFA11C7AC02E9BD9A10DE1536083A8D37BA48953E.
Supplied text: 29,180 characters as decoded locally including CRLF. Original bounded response: 20,000 characters including opaque citation and writing-block markup. Counts are not directly subtractable.
Normalize line endings, remove old opaque citation tokens and writing-block opener, and trim trailing line spaces for alignment only. The full normalized prefix matches. Verbatim evidence bytes are not normalized.

User identified this file as the complete recovered source after primary-conversation confirmation. It begins at the original response start, completes XVIII, includes XIX–XXIV, two analysis headings and the final recommendation to test the model before production contracts. No remaining known content gap against the supplied inventory. Full original platform export/end metadata was not independently retrieved. This provenance limit remains explicit and does not prevent accepting the user's recovered source.

Earlier attempts: reader cap; ChatGPT browser sign-in; no source files exposed in Claude PPU project. Q001 now CLOSED; old failure notes are historical. Hashes establish integrity, not independent proof of completeness. Reopen on conflicting source evidence.

## Research shelves — queued, not researched in WP0A
Inflation indexes (CPI-U NSA, C-CPI-U, PCE, global alternatives): WP1A.
TIPS/reference CPI, lag, revision, duration and basis: WP1A–1D and Phase 2.
Monetary economics/capital/liability matching: Phase 1.
Stablecoins/flatcoins: AMPL/SPOT, Nuon, ISC, FPI are prior leads, outcomes unverified.
Reserve management/tokenized assets: baseline first, alternatives later under 1D/2E.
Banking/custody/claims/capital: 1E and Phase 3; narrow-bank analogy not legal conclusion.
Payments/AP access/global settlement and Agorá comparison: 1F and later phases.
Blockchain/bridges: Phase 4; no selection.
Smart-contract security/oracles/upgrades: Phases 4–6.
Law/regulation/tax/accounting/bankruptcy: Phase 3; no new legal conclusions.

External statements and opaque historical citations remain unverified research leads. Future authorized work should record primary URL/title/publisher/date/version, supported claim and passage, limitations, contrary evidence and affected IDs.
