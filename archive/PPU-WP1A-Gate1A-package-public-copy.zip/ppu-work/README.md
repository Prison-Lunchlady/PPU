# PPU execution workspace
Version 0.1 • Recorded 2026-09-19 America/Chicago

Start with [Protocol State](01-protocol-state.md). This local folder is the persistent execution record for the existing PPU project. No separate cloud Work task or automatic sync to ChatGPT project sources has been created or claimed.

**Phase 0 / WP0A COMPLETE. Gate 0 APPROVED WITH CONDITIONS. WP1A COMPLETE FOR REVIEW; Gate 1A AWAITING REVIEW / NOT APPROVED. Next authorized package NONE. WP1B and later packages NOT AUTHORIZED.**

Current handoff: [WP1A completion report](wp1a/WP1A-completion-report.md), [proposed standard](wp1a/06-recommended-standard.md), [Gate 1A submission](wp1a/Gate-1A-submission.md). [User approval](evidence/gate0-approval-wp1a-authorization.md) preserves SRC003 provenance, architectural tensions and package boundaries. Earlier dated WP0A reports are historical; current Protocol State controls.

The ten canonical files are:
1. [Protocol State](01-protocol-state.md)
2. [Decision Register](02-decision-register.md)
3. [Risk Register](03-risk-register.md)
4. [Active Hypotheses](04-active-hypotheses.md)
5. [Unresolved Questions](05-unresolved-questions.md)
6. [Research Library Index](06-research-library-index.md)
7. [Development Roadmap](07-development-roadmap.md)
8. [Draft Monetary Constitution / Hypothesis Set](08-draft-constitution.md)
9. [Work Package Register](09-work-package-register.md)
10. [Review Gate Register](10-review-gate-register.md)

Supporting records: [structural review](reviews/wp0a-structural-review.md), [completion report](WP0A-report.md), [change log](CHANGELOG.md), and original captures in evidence/.

The full roadmap, initial user proposal, five original decision entries, fifteen original risks, eight hypotheses and latest Phase 0 response have been recovered. The earlier partial capture is retained. The user-supplied full response now closes Q001 with all 24 articles and post-constitution analysis preserved. See reviews/source-recovery-reconciliation.md.

## Maintenance contract
Use stable IDs; never reuse or silently renumber them. Keep accepted decisions separate from hypotheses. Append a dated amendment and its evidence when changing a record; preserve superseded text in evidence/history and record what superseded it. Dates for inherited decisions are recorded as unknown when not explicitly stated in the source.

The operator checks authorization in the Gate and Work Package registers before work. On completion, update affected records, Protocol State, change log and report together; check IDs, links, statuses and source coverage. No status wording can substitute for Brad's explicit approval. Record approval quote, source, date, conditions and exact next package before activation. Reviewer advice cannot authorize progression.

Routine documentation implementation is delegated to the current operator. Brad owns approvals; specialist research owners remain unassigned until a package is authorized. Read-only sources/ in the parent directory must never be modified. Keep source snapshots separate from maintained records. Preserve this folder when transferring the project; local files are not an off-device backup.

## Source precedence
Current user authorization and restrictions control scope. Adopted roadmap v0.1 controls process. Latest Phase 0 state qualifies the earlier constitution as a hypothesis set. Earlier proposal and constitution retain historical value; conflicts are logged, not silently reconciled into new policy. External claims in the old chat are unverified leads until researched in the appropriate authorized package.

## Review amendment — 2026-09-19
Claude Opus 5 High's [WP0A review](reviews/claude-opus-reconciliation.md) applied to the prior revision. The recovered revision subsequently received Brad's Gate 0 approval with conditions. A separate [WP1A review](wp1a/reviewer-reconciliation.md) and reasoned dispositions accompany this submission; neither review provides user approval.

Roadmap precedence: evidence/roadmap-v0.1-original.txt is the adopted source snapshot; 07-development-roadmap.md is its read-only-by-procedure verbatim mirror. A roadmap amendment requires documented authorized change and a new version, never silent edits to either v0.1 copy. The validator already compares their hashes.

## Status legend
- Decisions: Accepted = inherited accepted position; Accepted research methodology = inherited process choice, not an asset selection; Open hypothesis = unvalidated and no final choice; Critical unresolved architecture question = unresolved, not acceptance; implemented documentation choice = routine WP0A organization, not constitutional ratification.
- Hypotheses/questions: OPEN or UNVALIDATED = unresolved; a linked future package is a route, not authorization.
- Risks: OPEN = unresolved risk; OPEN residual = remaining limitation after a documented measure; Controlled in documentation or Controlled procedurally = a specified paperwork/process control exists, not monetary risk elimination.
- Packages: NOT AUTHORIZED always means not started in this workspace unless explicitly stated otherwise; WP0A deliverables-created/blocked means files exist but acceptance work remains.
- Gates: HOLD = no approval and remediation required; NOT REACHED = no gate submission or approval; not approved is explicit in every case. Approval must have user evidence.


## Source recovery revision 0.2
WP0A is complete and Gate 0 approved with conditions. Q001 is CLOSED on source recovery; Q019 is CLOSED on later direct approval. Source fidelity evidence remains in reviews/source-recovery-reconciliation.md. WP1A is now complete for review; no next package is authorized. Original roadmap and draft are unchanged.
